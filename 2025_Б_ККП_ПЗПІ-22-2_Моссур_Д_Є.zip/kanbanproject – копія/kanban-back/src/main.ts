// src/main.ts
// Ensure your CORS configuration is correct:

import { NestFactory } from '@nestjs/core';
import { ValidationPipe } from '@nestjs/common';
import { AppModule } from './app.module';
import * as dotenv from 'dotenv';
import * as cookieParser from 'cookie-parser';
import helmet from 'helmet';

async function bootstrap() {
  dotenv.config();
  
  const app = await NestFactory.create(AppModule);
  
  // CORS - Ensure this is correctly configured
  app.enableCors({
    origin: ['http://localhost:3000'], // Explicitly list your frontend origin
    credentials: true,
    methods: ['GET', 'HEAD', 'PUT', 'PATCH', 'POST', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization'],
  });
  
  // Security
  app.use(helmet());
  app.use(cookieParser());
  
  // Validation
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true,
      transform: true,
      forbidNonWhitelisted: true,
      transformOptions: {
        enableImplicitConversion: true,
      },
    }),
  );
  
  // Global API prefix
  app.setGlobalPrefix('api');
  
  // Port from environment + default
  const port = parseInt(process.env.PORT as string, 10) || 5005;
  // Listen on "0.0.0.0" for cloud environments
  await app.listen(port, '0.0.0.0');
  console.log(`🚀 Application is running on http://0.0.0.0:${port}`);
}

bootstrap();