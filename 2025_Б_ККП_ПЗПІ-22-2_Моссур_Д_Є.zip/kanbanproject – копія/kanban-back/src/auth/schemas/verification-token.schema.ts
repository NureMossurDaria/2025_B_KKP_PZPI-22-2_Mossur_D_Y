// src/auth/schemas/verification-token.schema.ts
import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import * as mongoose from 'mongoose';
import { User } from 'src/users/schemas/user.schema';

@Schema()
export class VerificationToken extends Document {
  @Prop({ type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true })
  userId: mongoose.Types.ObjectId;

  @Prop({ required: true, unique: true })
  token: string;

  @Prop({ default: Date.now })
  createdAt: Date;
}

export const VerificationTokenSchema = SchemaFactory.createForClass(VerificationToken);