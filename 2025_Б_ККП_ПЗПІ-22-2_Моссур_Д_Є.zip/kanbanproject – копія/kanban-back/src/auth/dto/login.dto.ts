// src/auth/dto/login.dto.ts
import {
  IsEmail,
  IsNotEmpty,
  IsString,
  IsBoolean,
  IsOptional,
} from 'class-validator';

export class LoginDto {
  @IsEmail({}, { message: 'Email має бути валідним' })
  @IsNotEmpty({ message: 'Email обовʼязковий' })
  email: string;

  @IsString({ message: 'Пароль має бути строкою' })
  @IsNotEmpty({ message: 'Пароль обовʼязковий' })
  password: string;

  @IsOptional()
  @IsBoolean({ message: 'rememberMe має бути булевим значенням' })
  rememberMe?: boolean;
}
