import { useState, useEffect, useCallback } from 'react';


export function useOfflineSupport() {
  const [isOnline, setIsOnline] = useState<boolean>(
    typeof navigator !== 'undefined' ? navigator.onLine : true
  );
  const [hasPendingChanges, setHasPendingChanges] = useState<boolean>(false);
  const [pendingChanges, setPendingChanges] = useState<any[]>([]);

  // Відстежуємо зміни стану мережі
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      
      // Якщо є незбережені зміни, можна запропонувати їх синхронізувати
      if (hasPendingChanges) {
        const shouldSync = window.confirm(
          'Інтернет-з\'єднання відновлено. Бажаєте синхронізувати незбережені зміни?'
        );
        
        if (shouldSync) {
          syncPendingChanges();
        }
      }
    };
    
    const handleOffline = () => {
      setIsOnline(false);
    };
    
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [hasPendingChanges]);

  // Перевіряємо, чи є доступ до IndexedDB для збереження даних локально
  const isIndexedDBAvailable = useCallback(() => {
    return typeof window !== 'undefined' && 'indexedDB' in window;
  }, []);

  // Додаємо зміну до черги змін для синхронізації
  const addPendingChange = useCallback((change: any) => {
    setPendingChanges(prev => [...prev, { ...change, timestamp: Date.now() }]);
    setHasPendingChanges(true);
    
    // Зберігаємо зміни в localStorage для відновлення при перезавантаженні
    if (typeof window !== 'undefined') {
      try {
        const existingChanges = JSON.parse(localStorage.getItem('pendingChanges') || '[]');
        localStorage.setItem(
          'pendingChanges',
          JSON.stringify([...existingChanges, { ...change, timestamp: Date.now() }])
        );
      } catch (error) {
        console.error('Error saving pending changes to localStorage:', error);
      }
    }
  }, []);

  // Синхронізуємо всі незбережені зміни, коли з'єднання відновлено
  const syncPendingChanges = useCallback(async () => {
    if (!isOnline || pendingChanges.length === 0) return;
    
    // Сортуємо зміни за часом
    const sortedChanges = [...pendingChanges].sort((a, b) => a.timestamp - b.timestamp);
    
    for (const change of sortedChanges) {
      try {
        // Тут виконуємо API-запит для цієї зміни
        await change.apiFunction(...change.params);
        
        // Видаляємо цю зміну зі списку
        setPendingChanges(prev => prev.filter(c => c.timestamp !== change.timestamp));
      } catch (error) {
        console.error('Error syncing pending change:', error);
        // Якщо помилка серверна або мережева, зупиняємо синхронізацію
        if (!navigator.onLine) {
          setIsOnline(false);
          break;
        }
      }
    }
    
    // Оновлюємо стан і localStorage
    if (pendingChanges.length === 0) {
      setHasPendingChanges(false);
      localStorage.removeItem('pendingChanges');
    } else {
      localStorage.setItem('pendingChanges', JSON.stringify(pendingChanges));
    }
  }, [isOnline, pendingChanges]);

  // Завантажуємо незбережені зміни при ініціалізації
  useEffect(() => {
    if (typeof window !== 'undefined') {
      try {
        const savedChanges = localStorage.getItem('pendingChanges');
        if (savedChanges) {
          const parsedChanges = JSON.parse(savedChanges);
          if (parsedChanges.length > 0) {
            setPendingChanges(parsedChanges);
            setHasPendingChanges(true);
          }
        }
      } catch (error) {
        console.error('Error loading pending changes from localStorage:', error);
      }
    }
  }, []);

  return {
    isOnline,
    hasPendingChanges,
    pendingChanges,
    addPendingChange,
    syncPendingChanges,
    isIndexedDBAvailable
  };
}

// Типи для контракту між компонентами та функціями локального збереження
export interface PendingChange {
  type: 'updateColumnOrder' | 'updateTaskOrder' | 'createTask' | 'updateTask' | 'deleteTask' | 'createColumn' | 'updateColumn' | 'deleteColumn';
  projectId: string;
  data: any;
  timestamp: number;
  apiFunction: Function;
  params: any[];
}

export interface OfflineSupportHook {
  isOnline: boolean;
  hasPendingChanges: boolean;
  pendingChanges: PendingChange[];
  addPendingChange: (change: Omit<PendingChange, 'timestamp'>) => void;
  syncPendingChanges: () => Promise<void>;
  isIndexedDBAvailable: () => boolean;
}