// src/api/offlineSupport.ts
import { KanbanBoard } from '@/components/kanban/Board';

// Константи для локального сховища
const BOARD_CACHE_PREFIX = 'board_cache_';
const PENDING_CHANGES_KEY = 'pendingChanges';

/**
 * Зберігає поточний стан дошки в локальному сховищі
 * @param projectId ID проекту
 * @param board Дані дошки
 */
export function saveBoardToLocalStorage(projectId: string, board: KanbanBoard) {
  try {
    localStorage.setItem(`${BOARD_CACHE_PREFIX}${projectId}`, JSON.stringify(board));
  } catch (error) {
    console.error('Error saving board to localStorage:', error);
  }
}

/**
 * Завантажує дошку з локального сховища
 * @param projectId ID проекту
 * @returns Дані дошки або null, якщо немає збережених даних
 */
export function loadBoardFromLocalStorage(projectId: string): KanbanBoard | null {
  try {
    const boardData = localStorage.getItem(`${BOARD_CACHE_PREFIX}${projectId}`);
    return boardData ? JSON.parse(boardData) : null;
  } catch (error) {
    console.error('Error loading board from localStorage:', error);
    return null;
  }
}

/**
 * Зберігає незбережену зміну в локальному сховищі
 * @param change Об'єкт зміни для синхронізації пізніше
 */
export function addPendingChange(change: any) {
  try {
    // Отримуємо поточні незбережені зміни
    const pendingChangesString = localStorage.getItem(PENDING_CHANGES_KEY);
    const pendingChanges = pendingChangesString ? JSON.parse(pendingChangesString) : [];
    
    // Додаємо нову зміну
    pendingChanges.push({
      ...change,
      timestamp: Date.now()
    });
    
    // Зберігаємо оновлений список
    localStorage.setItem(PENDING_CHANGES_KEY, JSON.stringify(pendingChanges));
  } catch (error) {
    console.error('Error adding pending change:', error);
  }
}

/**
 * Отримує список незбережених змін
 * @returns Масив незбережених змін
 */
export function getPendingChanges(): any[] {
  try {
    const pendingChangesString = localStorage.getItem(PENDING_CHANGES_KEY);
    return pendingChangesString ? JSON.parse(pendingChangesString) : [];
  } catch (error) {
    console.error('Error getting pending changes:', error);
    return [];
  }
}

/**
 * Видаляє незбережену зміну зі списку
 * @param timestamp Часова мітка зміни для видалення
 */
export function removePendingChange(timestamp: number) {
  try {
    const pendingChangesString = localStorage.getItem(PENDING_CHANGES_KEY);
    if (!pendingChangesString) return;
    
    const pendingChanges = JSON.parse(pendingChangesString);
    const updatedChanges = pendingChanges.filter((change: any) => change.timestamp !== timestamp);
    
    localStorage.setItem(PENDING_CHANGES_KEY, JSON.stringify(updatedChanges));
  } catch (error) {
    console.error('Error removing pending change:', error);
  }
}

/**
 * Перевіряє наявність з'єднання з мережею
 * @returns true, якщо є з'єднання з мережею
 */
export function isOnline(): boolean {
  return typeof navigator !== 'undefined' ? navigator.onLine : true;
}

/**
 * Оновлює дошку локально, якщо немає з'єднання з мережею
 * @param projectId ID проекту
 * @param updatedBoard Оновлені дані дошки
 * @param changeType Тип зміни
 * @param data Дані для зміни
 */
export function updateBoardOffline(
  projectId: string,
  updatedBoard: KanbanBoard,
  changeType: string,
  data: any
) {
  // Зберігаємо оновлену дошку в локальне сховище
  saveBoardToLocalStorage(projectId, updatedBoard);
  
  // Додаємо зміну до списку незбережених змін
  addPendingChange({
    type: changeType,
    projectId,
    data,
    timestamp: Date.now()
  });
  
  return updatedBoard;
}