'use client';

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import {
  format,
  startOfMonth,
  endOfMonth,
  startOfWeek,
  endOfWeek,
  eachDayOfInterval,
  isSameMonth,
  isSameDay,
  isToday,
  addMonths,
  subMonths,
  parseISO,
  isWithinInterval,
} from 'date-fns';
import { uk } from 'date-fns/locale';
import MainLayout from '@/components/layout/MainLayout';
import TaskDetailsModal from '@/components/kanban/TaskDetails';
import { Button } from '@/components/ui/Button/Button';
import styles from './page.module.css';
import { auth, tasks as tasksApi, projects as projectsApi } from '@/api/api';
import { addTaskToGoogleCalendar } from '@/utils/googleCalendar';
import { toast } from 'react-hot-toast';

// Типи даних
interface CalendarTask {
  id: string;
  title: string;
  description: string;
  projectId: string;
  projectName: string;
  createdAt: string;
  deadline: string;
  columnId: string;
  columnName: string;
}

export default function CalendarPage() {
  const router = useRouter();
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [tasks, setTasks] = useState<CalendarTask[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTask, setSelectedTask] = useState<CalendarTask | null>(null);
  const [isTaskDetailsOpen, setIsTaskDetailsOpen] = useState(false);
  const [viewMode, setViewMode] = useState<'month' | 'week' | 'day'>('month');
  const [user, setUser] = useState<any>(null);
  const [recentProjects, setRecentProjects] = useState<any[]>([]);
  const [userProjects, setUserProjects] = useState<any[]>([]);
  
  // Завантаження даних користувача, проектів та задач
  useEffect(() => {
    const fetchData = async () => {
      try {
        // Перевіряємо авторизацію
        const token = localStorage.getItem('authToken');
        if (!token) {
          router.push('/auth/login');
          return;
        }
        
        // Отримуємо дані користувача та проекти
        try {
          // Отримуємо дані користувача
          const userResponse = await auth.me();
          setUser(userResponse.data);
          
          // Спробуємо отримати проекти користувача через різні ендпоінти
          let projects = [];
          
          try {
            // Спочатку спробуємо через getUserProjects
            const userProjectsResponse = await projectsApi.getUserProjects();
            projects = userProjectsResponse.data || [];
          } catch (userProjectsError) {
            console.log('getUserProjects failed, trying getAll:', userProjectsError);
            
            try {
              // Якщо не вдалося, спробуємо через getAll
              const allProjectsResponse = await projectsApi.getAll();
              projects = allProjectsResponse.data || [];
            } catch (allProjectsError) {
              console.log('getAll projects also failed:', allProjectsError);
              
              try {
                // Останній шанс - спробуємо через recent projects
                const recentProjectsResponse = await auth.getRecentProjects();
                projects = recentProjectsResponse.data || [];
                console.log('Using recent projects as fallback');
              } catch (recentError) {
                console.log('All project endpoints failed:', recentError);
                projects = [];
              }
            }
          }
          
          setUserProjects(projects);
          
          // Встановлюємо недавні проекти (беремо перші 5)
          setRecentProjects(projects.slice(0, 5));
          
          // Завантажуємо задачі з проектів користувача
          const allTasks: CalendarTask[] = [];
          
          if (projects.length === 0) {
            console.log('No projects found for user');
          } else {
            console.log(`Found ${projects.length} projects, loading tasks...`);
            
            // Для кожного проекту отримуємо його задачі
            for (const project of projects) {
              try {
                const projectTasksResponse = await tasksApi.getAll(project.id);
                const projectTasks = projectTasksResponse.data || [];
                
                // Фільтруємо тільки задачі з дедлайнами
                const tasksWithDeadlines = projectTasks.filter((task: any) => task.deadline);
                
                if (tasksWithDeadlines.length > 0) {
                  console.log(`Found ${tasksWithDeadlines.length} tasks with deadlines in project: ${project.name}`);
                }
                
                // Форматуємо задачі для календаря
                const formattedTasks = tasksWithDeadlines.map((task: any) => ({
                  id: task.id,
                  title: task.title,
                  description: task.description || '',
                  projectId: task.projectId || project.id,
                  projectName: project.name,
                  createdAt: task.createdAt,
                  deadline: task.deadline,
                  columnId: task.columnId,
                  columnName: task.columnName || 'Задачі',
                }));
                
                allTasks.push(...formattedTasks);
              } catch (projectError) {
                console.error(`Error fetching tasks for project ${project.name} (${project.id}):`, projectError);
                
            //@ts-ignore
              if (projectError?.response?.status === 401) {
                  localStorage.removeItem('authToken');
                  toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
                  router.push('/auth/login');
                  return;
                }
                // Для інших помилок просто пропускаємо цей проект і продовжуємо
              }
            }
            
            console.log(`Total tasks with deadlines loaded: ${allTasks.length}`);
          }
          
          setTasks(allTasks);
          
        } catch (authError) {
          console.error('Authentication error:', authError);
          //@ts-ignore
          if (authError?.response?.status === 401) {
            localStorage.removeItem('authToken');
            toast.error('Сесія закінчилась. Будь ласка, увійдіть знову.');
            router.push('/auth/login');
          } else {
            // Якщо це інша помилка, показуємо її але не виходимо
            console.error('Non-auth error:', authError);
            toast.error('Помилка при завантаженні даних');
          }
          return;
        }
        
      } catch (error) {
        console.error('Error fetching data:', error);
        toast.error('Помилка при завантаженні даних');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchData();
  }, [router]);
  
  // Функція для перезавантаження задач
  const reloadTasks = async () => {
    try {
      const allTasks: CalendarTask[] = [];
      
      // Використовуємо збережені проекти користувача
      for (const project of userProjects) {
        try {
          const projectTasksResponse = await tasksApi.getAll(project.id);
          const projectTasks = projectTasksResponse.data || [];
          
          // Фільтруємо тільки задачі з дедлайнами
          const tasksWithDeadlines = projectTasks.filter((task: any) => task.deadline);
          
          // Форматуємо задачі для календаря
          const formattedTasks = tasksWithDeadlines.map((task: any) => ({
            id: task.id,
            title: task.title,
            description: task.description || '',
            projectId: task.projectId || project.id,
            projectName: project.name,
            createdAt: task.createdAt,
            deadline: task.deadline,
            columnId: task.columnId,
            columnName: task.columnName || 'Задачі',
          }));
          
          allTasks.push(...formattedTasks);
        } catch (projectError) {
          console.error(`Error fetching tasks for project ${project.id}:`, projectError);
        }
      }
      
      setTasks(allTasks);
    } catch (error) {
      console.error('Error reloading tasks:', error);
      toast.error('Помилка при оновленні задач');
    }
  };
  
  // Отримання днів для календаря
  const calendarDays = useMemo(() => {
    if (viewMode === 'month') {
      const monthStart = startOfMonth(currentMonth);
      const monthEnd = endOfMonth(currentMonth);
      const calendarStart = startOfWeek(monthStart, { weekStartsOn: 1 });
      const calendarEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });
      
      return eachDayOfInterval({ start: calendarStart, end: calendarEnd });
    } else if (viewMode === 'week') {
      const weekStart = startOfWeek(currentMonth, { weekStartsOn: 1 });
      const weekEnd = endOfWeek(currentMonth, { weekStartsOn: 1 });
      
      return eachDayOfInterval({ start: weekStart, end: weekEnd });
    } else {
      return [currentMonth];
    }
  }, [currentMonth, viewMode]);
  
  // Функція для перевірки, чи є задачі на певний день
  const getTasksForDay = (day: Date) => {
    return tasks.filter(task => {
      if (!task.deadline) return false;
      
      try {
        const deadlineDate = parseISO(task.deadline);
        return isSameDay(deadlineDate, day);
      } catch (error) {
        console.error(`Error parsing deadline for task ${task.id}:`, error);
        return false;
      }
    });
  };
  
  // Переходи по календарю
  const nextMonth = () => {
    setCurrentMonth(addMonths(currentMonth, 1));
  };
  
  const prevMonth = () => {
    setCurrentMonth(subMonths(currentMonth, 1));
  };
  
  // Перехід до поточної дати
  const goToToday = () => {
    setCurrentMonth(new Date());
  };
  
  // Обробники для модального вікна задачі
  const openTaskDetails = (task: CalendarTask) => {
    setSelectedTask(task);
    setIsTaskDetailsOpen(true);
  };
  
  const closeTaskDetails = () => {
    setIsTaskDetailsOpen(false);
    setSelectedTask(null);
  };
  
  // Функції роботи з задачами
  const handleEditTask = () => {
    setIsTaskDetailsOpen(false);
    if (selectedTask?.projectId) {
      router.push(`/dashboard/${selectedTask.projectId}`);
    }
  };
  
const handleDeleteTask = async () => {
  if (!selectedTask) return;
  
  // Перевіряємо токен перед видаленням
  const token = localStorage.getItem('authToken');
  if (!token) {
    toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
    router.push('/auth/login');
    return;
  }
  
  try {
    console.log('=== CALENDAR DELETE DEBUG ===');
    console.log('Task to delete:', {
      id: selectedTask.id,
      title: selectedTask.title,
      projectId: selectedTask.projectId,
      columnId: selectedTask.columnId,
      type: typeof selectedTask.id
    });
    
    // Перевіряємо що ID є валідним
    if (!selectedTask.id || selectedTask.id === 'undefined' || selectedTask.id === '') {
      throw new Error('Invalid task ID: ' + selectedTask.id);
    }
    
    // Використовуємо той самий API що і в Task компоненті
    console.log('Calling tasksApi.delete with ID:', selectedTask.id);
    await tasksApi.delete(selectedTask.id);
    
    console.log('Task deleted successfully via API');
    
    // Оновлюємо локальний стан - видаляємо задачу зі списку
    setTasks(prevTasks => {
      const updatedTasks = prevTasks.filter(task => task.id !== selectedTask.id);
      console.log('Local state updated. Tasks before:', prevTasks.length, 'after:', updatedTasks.length);
      return updatedTasks;
    });
    
    toast.success('Задачу успішно видалено');
    setIsTaskDetailsOpen(false);
    setSelectedTask(null);
    
    // Перезавантажуємо задачі для синхронізації
    setTimeout(async () => {
      console.log('Reloading tasks for synchronization...');
      await reloadTasks();
    }, 1000);
    
  } catch (error: any) {
    console.error('=== DELETE ERROR ===');
    console.error('Full error object:', error);
    console.error('Error response:', error?.response);
    console.error('Error status:', error?.response?.status);
    console.error('Error data:', error?.response?.data);
    
    // Перевіряємо тип помилки
    if (error?.response?.status === 401) {
      localStorage.removeItem('authToken');
      toast.error('Сесія закінчилась. Перенаправляємо на сторінку входу...');
      router.push('/auth/login');
    } else if (error?.response?.status === 404) {
      // Задача вже не існує на сервері - це OK, видаляємо з локального стану
      console.log('Task not found on server (404), removing from local state');
      setTasks(prevTasks => prevTasks.filter(task => task.id !== selectedTask.id));
      toast.success('Задачу видалено');
      setIsTaskDetailsOpen(false);
      setSelectedTask(null);
    } else if (error?.response?.status === 403) {
      toast.error('У вас немає прав для видалення цієї задачі');
    } else if (error?.message?.includes('Invalid task ID')) {
      toast.error('Помилка: некоректний ID задачі');
      console.error('Task ID validation failed for:', selectedTask.id);
    } else {
      toast.error('Помилка при видаленні задачі. Спробуйте ще раз.');
      console.error('Unknown delete error, not updating local state');
    }
  }
};
  
  const handleAddToCalendar = (e: React.MouseEvent) => {
    e.stopPropagation();
    
    if (!selectedTask) return;
    
    try {
      addTaskToGoogleCalendar({
        title: selectedTask.title,
        description: selectedTask.description,
        deadline: selectedTask.deadline,
        projectName: selectedTask.projectName,
      });
      toast.success('Задачу додано до Google Calendar');
    } catch (error) {
      console.error('Error adding to Google Calendar:', error);
      toast.error('Помилка при додаванні до Google Calendar');
    }
  };
  
  // Функція для відображення карток задач на певний день
  const renderTasksForDay = (day: Date) => {
    const tasksForDay = getTasksForDay(day);
    
    if (tasksForDay.length === 0) {
      return null;
    }
    
    return (
      <div className={styles.tasksList}>
        {tasksForDay.map((task, idx) => (
          <div
            key={`${task.id}-${idx}`}
            className={styles.taskCard}
            onClick={() => openTaskDetails(task)}
          >
            <div className={styles.taskTime}>
              {format(parseISO(task.deadline), 'HH:mm', { locale: uk })}
            </div>
            <div className={styles.taskTitle}>{task.title}</div>
            <div className={styles.taskProject}>{task.projectName}</div>
          </div>
        ))}
      </div>
    );
  };
  
  // Функція для виходу з системи
  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/auth/login');
  };
  
  // Відображення заглушки під час завантаження
  if (isLoading) {
    return (
      <MainLayout 
        user={null} 
        recentProjects={[]}
        onLogout={handleLogout}
      >
        <div className={styles.loadingContainer}>
          <div className={styles.spinner}></div>
          <p>Завантаження календаря...</p>
        </div>
      </MainLayout>
    );
  }

  return (
    <MainLayout 
      user={user} 
      recentProjects={recentProjects}
      onLogout={handleLogout}
    >
      <div className={styles.calendarContainer}>
        <div className={styles.calendarHeader}>
          <div className={styles.calendarTitle}>
            <h1>Календар задач</h1>
            <div className={styles.taskCount}>
              {tasks.length > 0 && (
                <span>Знайдено задач з дедлайнами: {tasks.length}</span>
              )}
            </div>
          </div>
          
          <div className={styles.calendarControls}>
            <div className={styles.viewControls}>
              <Button 
                variant={viewMode === 'month' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setViewMode('month')}
              >
                Місяць
              </Button>
              <Button 
                variant={viewMode === 'week' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setViewMode('week')}
              >
                Тиждень
              </Button>
              <Button 
                variant={viewMode === 'day' ? 'primary' : 'outline'} 
                size="sm"
                onClick={() => setViewMode('day')}
              >
                День
              </Button>
            </div>
            
            <div className={styles.navigationControls}>
              <Button 
                variant="ghost"
                size="sm"
                onClick={prevMonth}
                aria-label="Попередній період"
              >
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" strokeWidth="2" fill="none">
                  <polyline points="15 18 9 12 15 6" />
                </svg>
              </Button>
              
              <Button 
                variant="ghost"
                onClick={goToToday}
              >
                Сьогодні
              </Button>
              
              <Button 
                variant="ghost"
                size="sm"
                onClick={nextMonth}
                aria-label="Наступний період"
              >
                <svg viewBox="0 0 24 24" width="18" height="18" stroke="currentColor" strokeWidth="2" fill="none">
                  <polyline points="9 18 15 12 9 6" />
                </svg>
              </Button>
              
              <Button 
                variant="outline"
                size="sm"
                onClick={reloadTasks}
                aria-label="Оновити задачі"
              >
                <svg viewBox="0 0 24 24" width="16" height="16" stroke="currentColor" strokeWidth="2" fill="none">
                  <polyline points="23 4 23 10 17 10" />
                  <polyline points="1 20 1 14 7 14" />
                  <path d="m3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
                </svg>
                Оновити
              </Button>
            </div>
            
            <div className={styles.currentPeriod}>
              {viewMode === 'month' && (
                <h2>{format(currentMonth, 'LLLL yyyy', { locale: uk })}</h2>
              )}
              {viewMode === 'week' && (
                <h2>
                  {format(startOfWeek(currentMonth, { weekStartsOn: 1 }), 'd MMM', { locale: uk })} - 
                  {format(endOfWeek(currentMonth, { weekStartsOn: 1 }), 'd MMM yyyy', { locale: uk })}
                </h2>
              )}
              {viewMode === 'day' && (
                <h2>{format(currentMonth, 'd MMMM yyyy', { locale: uk })}</h2>
              )}
            </div>
          </div>
        </div>
        
        <div className={`${styles.calendar} ${styles[`view-${viewMode}`]}`}>
          {/* Дні тижня */}
          {viewMode !== 'day' && (
            <div className={styles.weekdays}>
              {['Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб', 'Нд'].map((day) => (
                <div key={day} className={styles.weekday}>
                  {day}
                </div>
              ))}
            </div>
          )}
          
          {/* Дні місяця */}
          <div className={styles.days}>
            {calendarDays.map((day) => (
              <div
                key={day.toString()}
                className={`
                  ${styles.day}
                  ${!isSameMonth(day, currentMonth) ? styles.otherMonth : ''}
                  ${isToday(day) ? styles.today : ''}
                `}
              >
                <div className={styles.dayHeader}>
                  {viewMode === 'day' ? (
                    <div className={styles.dayName}>
                      {format(day, 'EEEE', { locale: uk })}
                    </div>
                  ) : (
                    <div className={styles.dayNumber}>
                      {format(day, 'd', { locale: uk })}
                    </div>
                  )}
                </div>
                
                <div className={styles.dayContent}>
                  {renderTasksForDay(day)}
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Повідомлення коли немає задач */}
        {tasks.length === 0 && !isLoading && (
          <div className={styles.emptyState}>
            <div className={styles.emptyIcon}>📅</div>
            <h3>Задач з дедлайнами не знайдено</h3>
            <p>Створіть нові задачі в ваших проектах і встановіть для них дедлайни, щоб вони відобразились у календарі.</p>
            <Button 
              variant="primary"
              onClick={() => router.push('/dashboard')}
            >
              Перейти до проектів
            </Button>
          </div>
        )}
      </div>
      
      {/* Модальне вікно з деталями задачі */}
      {selectedTask && (
        <TaskDetailsModal
        isOpen={isTaskDetailsOpen}
        onClose={closeTaskDetails}
        task={{
          id: selectedTask.id,
          title: selectedTask.title,
          description: selectedTask.description,
          createdAt: selectedTask.createdAt,
          deadline: selectedTask.deadline,
          labels: [selectedTask.projectName, selectedTask.columnName],
         
        }}
        onEdit={handleEditTask}
        // onDelete={handleDeleteTask} - УБИРАЕМ
        onAddToCalendar={handleAddToCalendar}
        context="calendar" // Указываем контекст календаря
        hideDeleteButton={true} // Явно скрываем кнопку удаления
      />
      )}
    </MainLayout>
  );
}