// src/app/auth/verify/[token]/ClientVerify.tsx
'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { auth } from '@/api/api';
import styles from './page.module.css';
import Link from 'next/link';
import { Button } from '@/components/ui/Button/Button';

export default function ClientVerify() {
  const router = useRouter();
  const [status, setStatus] = useState<'loading'|'success'|'error'>('loading');
  const [errorMessage, setErrorMessage] = useState('');
  const params = useParams();
  const token = Array.isArray(params.token) ? params.token[0] : params.token;

  useEffect(() => {
    // Immediately check if token is undefined and set error state if it is
    if (!token) {
      setStatus('error');
      setErrorMessage('Токен підтвердження відсутній');
      return;
    }

    (async () => {
      try {
        const { data } = await auth.verifyEmail(token);
        localStorage.setItem('authToken', data.token ?? data.accessToken);
        setStatus('success');
      } catch (err: any) {
        setStatus('error');
        setErrorMessage(err.response?.data?.message ?? 'Недійсний токен');
      }
    })();
  }, [token]);

  useEffect(() => {
    if (status === 'success') {
      const t = setTimeout(() => router.push('/dashboard'), 3000);
      return () => clearTimeout(t);
    }
  }, [status, router]);

  if (status === 'loading') {
    return <div className={styles.verifyCard}>Перевіряємо токен…</div>;
  }
  if (status === 'error') {
    return (
      <div className={styles.verifyCard}>
        <p>{errorMessage}</p>
        <Link href="/auth/verify"><Button>Спробувати знову</Button></Link>
      </div>
    );
  }
  return (
    <div className={styles.verifyCard}>
      <p>Email підтверджено! Зараз переходимо на Dashboard…</p>
      <Link href="/dashboard"><Button>Перейти зараз</Button></Link>
    </div>
  );
}