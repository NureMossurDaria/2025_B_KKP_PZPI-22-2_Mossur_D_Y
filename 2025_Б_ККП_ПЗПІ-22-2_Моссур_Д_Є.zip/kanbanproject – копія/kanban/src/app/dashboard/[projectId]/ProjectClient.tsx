'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import MainLayout from '@/components/layout/MainLayout';
import Board, { KanbanBoard } from '@/components/kanban/Board';
import styles from './page.module.css';
import { auth, projects as projectsApi, columns as columnsApi, tasks as tasksApi } from '@/api/api';
import toast from 'react-hot-toast';

interface ProjectClientProps {
  projectId: string;
}

export default function ProjectClient({ projectId }: ProjectClientProps) {
  const router = useRouter();
  const [board, setBoard] = useState<KanbanBoard | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [user, setUser] = useState<any>(null);
  const [recentProjects, setRecentProjects] = useState<any[]>([]);
  const [isSaving, setIsSaving] = useState(false);
  
  // Функція для обробки мережевих помилок
  const handleNetworkError = useCallback((error: any, message: string) => {
    console.error(`${message}:`, error);
    
    // Перевіряємо тип помилки
    if (error.message === 'Network Error') {
      toast.error('Помилка з`єднання з сервером. Перевірте підключення до інтернету.');
    } else if (error.response?.status === 401) {
      // Якщо помилка авторизації, перенаправляємо на сторінку входу
      localStorage.removeItem('authToken');
      router.push('/auth/login');
      toast.error('Сесія закінчилась. Будь ласка, увійдіть знову.');
    } else if (error.response?.status === 403) {
      toast.error('Недостатньо прав для цієї дії');
    } else if (error.response?.status === 404) {
      toast.error('Ресурс не знайдено');
    } else if (error.response?.status >= 500) {
      toast.error('Помилка на сервері. Спробуйте пізніше.');
    } else {
      // Виводимо повідомлення з сервера або стандартне повідомлення
      const errorMessage = error.response?.data?.message || error.message || message;
      toast.error(errorMessage);
    }
    
    return null;
  }, [router]);
  // всередині ProjectClient
const handleAddColumn = useCallback(
  async (title: string) => {
    setIsSaving(true);
    try {
      const res = await columnsApi.create({ title, projectId });
      const newColumn = res.data;
      setBoard(prev => {
        if (!prev) return prev;
        const id = newColumn.id || newColumn._id;
        const updated = {
          ...prev,
          columns: {
            ...prev.columns,
            [id]: { id, title: newColumn.title, taskIds: [] },
          },
          columnOrder: [...prev.columnOrder, id],
        };
        return updated;
      });
      toast.success('Колонку створено');
    } catch (e) {
      handleNetworkError(e, 'Не вдалося створити колонку');
    } finally {
      setIsSaving(false);
    }
  },
  [projectId, handleNetworkError]
);

  // Ефект для завантаження даних дошки
  useEffect(() => {
    const fetchBoard = async () => {
      try {
        // First check if projectId is valid
        if (!projectId) {
          setLoadError('Недійсний ID проекту');
          setIsLoading(false);
          return;
        }
        
        // Перевіряємо авторизацію
        const token = localStorage.getItem('authToken');
        if (!token) {
          router.push('/auth/login');
          return;
        }
        
        // Отримуємо дані користувача
        try {
          const userResponse = await auth.me();
          setUser(userResponse.data);
        } catch (authError) {
          handleNetworkError(authError, 'Помилка авторизації');
          router.push('/auth/login');
          return;
        }
        
        // Отримуємо останні проекти для сайдбару
        try {
          const recentProjectsResponse = await auth.getRecentProjects();
          setRecentProjects(recentProjectsResponse?.data || []);
        } catch (projectsError) {
          console.error('Error fetching recent projects:', projectsError);
          // Не критична помилка, продовжуємо завантаження
        }
        
        // Отримуємо дані проекту
        try {
          const projectResponse = await projectsApi.getById(projectId);
          const project = projectResponse.data;
          
          // Отримуємо колонки проекту
          const columnsResponse = await columnsApi.getAll(projectId);
          const columns = columnsResponse.data;
          
          // Отримуємо задачі проекту
          const tasksResponse = await tasksApi.getAll(projectId);
          const tasksData = tasksResponse.data;
          
          // Формуємо дані для дошки
          const boardData: KanbanBoard = {
            id: project._id || project.id,
            title: project.name,
            columns: {},
            columnOrder: project.columnOrder || [],
            tasks: {},
          };
          
          // Заповнюємо колонки
          columns.forEach((column: any) => {
            const columnId = column._id || column.id;
            boardData.columns[columnId] = {
              id: columnId,
              title: column.title,
              taskIds: Array.isArray(column.taskIds) ? column.taskIds : [],
            };
            
            // Додаємо ID колонки до порядку, якщо його ще немає
            if (!boardData.columnOrder.includes(columnId)) {
              boardData.columnOrder.push(columnId);
            }
          });
          
          // Заповнюємо задачі
          tasksData.forEach((task: any) => {
            const taskId = task._id || task.id;
            boardData.tasks[taskId] = {
              id: taskId,
              title: task.title || 'Без назви',
              description: task.description || '',
              createdAt: task.createdAt || new Date().toISOString(),
              deadline: task.deadline || undefined,
              labels: Array.isArray(task.labels) ? task.labels : [],
            };
            
            // Перевіряємо, чи є задача у відповідній колонці
            const columnId = task.columnId;
            if (columnId && boardData.columns[columnId]) {
              // Додаємо задачу в колонку, якщо її там ще немає
              if (!boardData.columns[columnId].taskIds.includes(taskId)) {
                boardData.columns[columnId].taskIds.push(taskId);
              }
            }
          });
          
          console.log('Initial board data loaded:', boardData);
          setBoard(boardData);
        } catch (error) {
          handleNetworkError(error, 'Помилка завантаження проекту');
          setLoadError('Не вдалося завантажити проект. Спробуйте пізніше.');
        }
      } catch (error: any) {
        handleNetworkError(error, 'Помилка завантаження дошки');
        setLoadError('Помилка при завантаженні дошки');
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchBoard();
  }, [projectId, router, handleNetworkError]);
  
  // ВИПРАВЛЕНА функція оновлення дошки - тепер просто оновлює стан
  const handleBoardChange = useCallback((updatedBoard: KanbanBoard) => {
    console.log('Board change received:', {
      columnsCount: Object.keys(updatedBoard.columns).length,
      tasksCount: Object.keys(updatedBoard.tasks).length,
      columnOrder: updatedBoard.columnOrder
    });
    
    // Створюємо новий об'єкт з deep copy для guarantee immutability
    const newBoard: KanbanBoard = {
      ...updatedBoard,
      columns: { ...updatedBoard.columns },
      tasks: { ...updatedBoard.tasks },
      columnOrder: [...updatedBoard.columnOrder]
    };
    
    // Додаткове deep copy для колонок і задач
    Object.keys(newBoard.columns).forEach(columnId => {
      newBoard.columns[columnId] = {
        ...newBoard.columns[columnId],
        taskIds: [...newBoard.columns[columnId].taskIds]
      };
    });
    
    Object.keys(newBoard.tasks).forEach(taskId => {
      newBoard.tasks[taskId] = {
        ...newBoard.tasks[taskId],
        labels: newBoard.tasks[taskId].labels ? [...newBoard.tasks[taskId].labels!] : []
      };
    });
    
    setBoard(newBoard);
    console.log('Board state updated');
  }, []);
  
  // Функція для ручного оновлення даних дошки
  const refreshBoard = useCallback(async () => {
    setIsLoading(true);
    setLoadError(null);
    
    try {
      const projectResponse = await projectsApi.getById(projectId);
      const project = projectResponse.data;
      
      const columnsResponse = await columnsApi.getAll(projectId);
      const columns = columnsResponse.data;
      
      const tasksResponse = await tasksApi.getAll(projectId);
      const tasksData = tasksResponse.data;
      
      // Формуємо дані для дошки
      const boardData: KanbanBoard = {
        id: project._id || project.id,
        title: project.name,
        columns: {},
        columnOrder: project.columnOrder || [],
        tasks: {},
      };
      
      // Заповнюємо колонки
      columns.forEach((column: any) => {
        const columnId = column._id || column.id;
        boardData.columns[columnId] = {
          id: columnId,
          title: column.title,
          taskIds: Array.isArray(column.taskIds) ? column.taskIds : [],
        };
        
        if (!boardData.columnOrder.includes(columnId)) {
          boardData.columnOrder.push(columnId);
        }
      });
      
      // Заповнюємо задачі
      tasksData.forEach((task: any) => {
        const taskId = task._id || task.id;
        boardData.tasks[taskId] = {
          id: taskId,
          title: task.title || 'Без назви',
          description: task.description || '',
          createdAt: task.createdAt || new Date().toISOString(),
          deadline: task.deadline || undefined,
          labels: Array.isArray(task.labels) ? task.labels : [],
        };
        
        const columnId = task.columnId;
        if (columnId && boardData.columns[columnId]) {
          if (!boardData.columns[columnId].taskIds.includes(taskId)) {
            boardData.columns[columnId].taskIds.push(taskId);
          }
        }
      });
      
      setBoard(boardData);
      setLoadError(null);
      toast.success('Дошку успішно оновлено');
    } catch (error) {
      handleNetworkError(error, 'Помилка оновлення дошки');
      setLoadError('Не вдалося оновити дошку');
    } finally {
      setIsLoading(false);
    }
  }, [projectId, handleNetworkError]);
  
  // Функція виходу з системи
  const handleLogout = () => {
    localStorage.removeItem('authToken');
    router.push('/auth/login');
  };
  const handleAddTask = useCallback(
    async (columnId: string, title: string, description: string, deadline?: string) => {
      if (!title.trim()) {
        toast.error('Назва задачі не може бути пустою');
        return;
      }
      setIsSaving(true);
      try {
        const res = await tasksApi.create({
          title: title.trim(),
          description,
          columnId,
          projectId,
          deadline
        });
        const newTask = res.data;
        const id = newTask._id || newTask.id;
  
        setBoard(prev => {
          if (!prev) return prev;
          // Додаємо нову таску в tasks
          const updatedTasks = {
            ...prev.tasks,
            [id]: {
              id,
              title: newTask.title,
              description: newTask.description || '',
              createdAt: newTask.createdAt,
              deadline: newTask.deadline,
              labels: newTask.labels || []
            }
          };
          // Додаємо ID таски в колонку
          const updatedColumn = {
            ...prev.columns[columnId],
            taskIds: [...prev.columns[columnId].taskIds, id]
          };
  
          return {
            ...prev,
            tasks: updatedTasks,
            columns: {
              ...prev.columns,
              [columnId]: updatedColumn
            }
          };
        });
  
        toast.success('Задачу створено');
      } catch (e) {
        handleNetworkError(e, 'Не вдалося створити задачу');
      } finally {
        setIsSaving(false);
      }
    },
    [projectId, handleNetworkError]
  );
  
  const handleUpdateTask = useCallback(
    async (taskId: string, updated: any) => {
      setIsSaving(true);
      try {
        await tasksApi.update(taskId, updated);
        setBoard(prev => {
          if (!prev) return prev;
          return {
            ...prev,
            tasks: {
              ...prev.tasks,
              [taskId]: {
                ...prev.tasks[taskId],
                ...updated
              }
            }
          };
        });
        toast.success('Задачу оновлено');
      } catch (e) {
        handleNetworkError(e, 'Не вдалося оновити задачу');
      } finally {
        setIsSaving(false);
      }
    },
    [handleNetworkError]
  );
  
  const handleDeleteTask = useCallback(
    async (taskId: string, columnId: string) => {
      setIsSaving(true);
      try {
        await tasksApi.delete(taskId);
        setBoard(prev => {
          if (!prev) return prev;
          const { [taskId]: _, ...remainingTasks } = prev.tasks;
          const updatedColumn = {
            ...prev.columns[columnId],
            taskIds: prev.columns[columnId].taskIds.filter(id => id !== taskId)
          };
          return {
            ...prev,
            tasks: remainingTasks,
            columns: {
              ...prev.columns,
              [columnId]: updatedColumn
            }
          };
        });
        toast.success('Задачу видалено');
      } catch (e) {
        handleNetworkError(e, 'Не вдалося видалити задачу');
      } finally {
        setIsSaving(false);
      }
    },
    [handleNetworkError]
  );
  // Додаємо useEffect для логування змін board
  useEffect(() => {
    if (board) {
      console.log('Board state changed:', {
        id: board.id,
        title: board.title,
        columnsCount: Object.keys(board.columns).length,
        tasksCount: Object.keys(board.tasks).length,
        columnOrder: board.columnOrder
      });
    }
  }, [board]);
  
  // Відображаємо лоадер під час завантаження даних
  if (isLoading) {
    return (
      <MainLayout 
        user={null} 
        recentProjects={[]}
        onLogout={handleLogout}
      >
        <div className={styles.loadingContainer}>
          <div className={styles.spinner}></div>
          <p>Завантаження дошки...</p>
        </div>
      </MainLayout>
    );
  }
  
  // Якщо є помилка при завантаженні
  if (loadError) {
    return (
      <MainLayout 
        user={user} 
        recentProjects={recentProjects}
        onLogout={handleLogout}
      >
        <div className={styles.errorContainer}>
          <div className={styles.errorIcon}>⚠️</div>
          <h2>Помилка при завантаженні дошки</h2>
          <p>{loadError}</p>
          <div className={styles.errorActions}>
            <button 
              className={styles.errorButton}
              onClick={() => router.push('/dashboard')}
            >
              Перейти до списку проектів
            </button>
            <button 
              className={styles.errorButton}
              onClick={refreshBoard}
            >
              Спробувати знову
            </button>
          </div>
        </div>
      </MainLayout>
    );
  }
  
  // Якщо дошка не знайдена, перенаправляємо на список проектів
  if (!board) {
    router.push('/dashboard');
    return null;
  }

  return (
    <MainLayout 
      user={user} 
      recentProjects={recentProjects}
      onLogout={handleLogout}
    >
      <div className={styles.boardContainer}>
        {isSaving && (
          <div className={styles.savingIndicator}>
            <div className={styles.spinner}></div>
            <span>Збереження змін...</span>
          </div>
        )}
       <Board
        board={board}
        onBoardChange={handleBoardChange}
        onAddColumn={handleAddColumn} 
        onAddTask={handleAddTask}
        onUpdateTask={handleUpdateTask}
        onDeleteTask={handleDeleteTask}
      />
      </div>
    </MainLayout>
  );
}